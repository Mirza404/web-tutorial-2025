# Setting up Tailwind

## What will we do?
For this tutorial, we will be using Tailwind directly from the net.

```<!DOCTYPE html>
<html lang="en">
  <head>
    ...other parameters
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>
  ...code
  </body>
</html>
```

Just like here. We will also have 2 tasks for you to try it out. 